//
//  Category.swift
//  MuraliRestaurant
//
//  Created by Kalla,Muralidhar Reddy on 3/22/22.
//

import Foundation

// MARK: - Welcome
struct Categories: Codable {
    let categories: [String]
}
